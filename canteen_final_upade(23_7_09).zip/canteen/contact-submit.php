<?php
    session_start();
    include("admin/confs/config.php");

    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $message = $_POST['message'];

    $sql = "INSERT INTO contact_us( name, email, phone, message, create_at) VALUES ('$name','$email','$phone','$message',now())";
    mysqli_query($conn, $sql);

    header("location: msg-rev.php");


?>
