<?php
//include("admin/confs/auth.php");
    include 'header.php';
    if(isset($_SESSION['auth_user'])){
        echo ($_SESSION['auth_user']);
    }

?>

<section id="products">
	<div class="container">

		<div class="row">
			<div class="col-md-12">
				<div class="products-heading">
					<h2>CANTEEN THREE</h2>
				</div>
			</div>
        </div>

        <div class="row">
            <?php while($row = mysqli_fetch_assoc($products3)): ?>
                <div class="col-md-3">
                    <div class="products">
                        <a href="product-detail.php?id=<?php echo $row['id'] ?>">
                            <img src="./admin/images/<?php echo $row['image']; ?>" alt="">
                        </a>
                        <a href="product-detail.php?id=<?php echo $row['id'] ?>">
                            <h4><?php echo $row['title']; ?></h4>
                        </a>
                        <p class="price"><?php echo $row['price']; ?> Kyats</p>
                        <?php if(isset($_SESSION['auth_user'])): ?>
                        <a class="view-link shutter" href="add-to-cart.php?id=<?php echo $row['id'] ?>">
                            <i class="fa fa-plus-circle"></i>Add To Cart</a>
                        <?php else: ?>
                        <a class="view-link shutter" href="#">
                            <i class="fa fa-plus-circle"></i>Login Please</a>
                        <?php endif; ?>
                    </div>	<!-- End of /.products -->
                </div>	<!-- End of /.col-md-3 -->
            <?php endwhile; ?>

        </div>

    </div><!--end of container -->
</section>

<?php include 'footer.php';?>