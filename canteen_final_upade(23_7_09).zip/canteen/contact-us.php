<?php
//include("admin/confs/auth.php");
    include 'header.php';
    if(isset($_SESSION['auth_user'])){
        //echo ($_SESSION['auth_user']);
    }
?>
<!-- CONTACT START
	==================================== -->
    <section>
	<div class="container">
		<div class="row contact_body">
			<div class="col-sm-4">
				<div class="flex-box">
					<i class="fa fa-map-marker contact_icon" aria-hidden="true"></i>
					<h4 class="contact_txt">ADDRESS</h4>
					<p>U Htun Lin Street, InnSein Road </p>
					<span>Bo1000, Yangon.</span>
				</div>
			</div>
			<div class="col-sm-4">
				<div class="flex-box">
					<i class="fa fa-phone contact_icon"></i>
					<h4 class="contact_txt">CALL US</h4>
					<p>+95 9420253928</p>
					<span>+95 9420253928</span>
				</div>
			</div>
			<div class="col-sm-4">
				<div class="flex-box">
					<i class="fa fa-envelope-o contact_icon"></i>
					<h4 class="contact_txt">EMAIL</h4>
					<p class="contact_mail">contact@canteenfood.com</p>
				</div>
			</div>
		</div>
	</div>
</section>

<!-- Contact form start
========================= -->
<section>
	<div class="container">
		<div class="row">
			<div class="col-sm-6">
				<div>
					<h4>FOR MORE INFORMATION</h4>
					<div class="contact_box">
						<i class="fa fa-phone contact__right_icon"></i>
						<div class="contact-right">
							<p class="contact_txt">TELEPHONE</p>
							<span>+95 9420253928</span>
						</div>
					</div>
					<div class="contact_box">
						<i class="fa fa-envelope-o contact__right_icon"></i>
						<div class="contact-right">
							<p class="contact_txt">MAIL</p>
							<span>contact@homeparadise.com</span>
						</div>
					</div>
					<div class="contact_box">
						<i class="fa fa-phone contact__right_icon"></i>
						<div class="contact-right">
							<p class="contact_txt">	Location</p>
							<span>Hlaetan street, Bo1000, Yangon.
							</span>
						</div>
					</div>
					<ul>
						<li class="social_title">SHARE ON</li>
						<li class="f_left">
							<a href="">
								<div class="social_icon">
									<i class="fa fa-facebook"></i>
								</div>
							</a></li>
							<li class="f_left">
								<a href="">
									<div class="social_icon">
										<i class="fa fa-twitter"></i>
									</div>
								</a>
							</li>
							<li class="f_left">
								<div class="social_icon">
									<i class="fa fa-instagram"></i>
								</div>
							</li>
							<li class="f_left">
								<a href="">
									<div class="social_icon">
										<i class="fa fa-linkedin"></i>
									</div>
								</a>
							</li>
						</ul>
					</div>

					</div><!-- End of col-sm-6 -->
					<div class="col-sm-6">
						<div class="row contact_form_body">
							<h4>Contact Form</h4>
							<form action="contact-submit.php" method="POST" class="order_form contact_form">
								<div class="">

									<label class="order_label contact_label ">Name</label>
									<input type="text" name="name"  required="" class="order_input contact_input">
								</div>
								<div class="">

									<label class="order_label contact_label">Email</label>
									<input type="email" name="email"  required="" class="order_input contact_input">
								</div>
								<div class="">

									<label class="order_label contact_label">Phone Number</label>
									<input type="text" name="phone"  required="" class="order_input contact_input">
								</div>
							<div class="">

								<label class="order_label contact_label">Message</label>
								<textarea name="message" class="order_textarea contact_textarea" required=""></textarea>
                            </div>
                            <input class="btn btn-success btn-send" type="submit" value="SEND">

					</form>
				</div>
			</div>
		</div>
	</div>

</section>


<?php include 'footer.php';?>