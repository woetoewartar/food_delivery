<?php
    include("confs/auth.php");
    include("confs/config.php");
    $id = $_POST['id'];
    $name = $_POST['name'];
    $remark = $_POST['remark'];
    $sql = "UPDATE canteens SET name='$name', remark='$remark', update_at=now() WHERE id = '$id' ";
    mysqli_query($conn, $sql);
    header("location: can-list.php");
?>
