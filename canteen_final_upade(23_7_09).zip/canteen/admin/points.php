<?php
include("confs/auth.php");
include 'layouts/header.php';?>

<div id="content-wrapper">
    <div class="container-fluid">
    

    <!-- Here Start the list of canteens -->
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-bordered text-center" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th>Name</th>
              <th>Points</th>
              <th>Edit</th>
            </tr>
          </thead>
          <?php
            include("confs/config.php");
            $sql = "SELECT points.*,users.name FROM users LEFT JOIN points ON points.user_id = users.id WHERE is_admin = 0";

            $result = mysqli_query($conn, $sql);
          ?>
          <?php while($row = mysqli_fetch_assoc($result)): ?>
          <tr>
            <td><?php echo $row['name'] ?></td>
            <td><?php echo $row['points'] ?></td>
            <td><a href="point-edit.php?id=<?php echo $row['id'] ?>"><button class="edit_btn btn info"><i class="far fa-edit"></i>Edit</button></a> </td>
          </tr>
          <?php endwhile; ?>
          <tbody>

          </tbody>
        </table>
      </div>
    </div>
    <!-- Here End the list of canteens -->
    </div>
  </div>

<?php include 'layouts/footer.php';?>
