<?php
    include("confs/auth.php");
    include 'layouts/header.php';

?>
  <div id="content-wrapper">
  <div class="container-fluid">

        <?php
            include("confs/config.php");
            $orders = mysqli_query($conn, "SELECT * FROM orders");
        ?>

        <div class="table-responsive">
        <table class="table table-bordered text-center" width="100%" cellspacing="0">
            <thead>
                <tr>
                    <th>Customer</th>
                    <th>Status</th>
                    <th>Order items</th>
                    <th>Action</th>
                </tr>
            </thead>
            <?php while($order = mysqli_fetch_assoc($orders)): ?>
                <tr>
                    <td><?php echo $order['name'] ?></br>
                    <?php echo $order['email'] ?></br>
                    <?php echo $order['phone'] ?></br>
                    <?php echo $order['address'] ?></td>

                    <td><?php if($order['status']): ?>
                            * <a href="order-status.php?id=<?php echo $order['id'] ?>&status=0">
                            Undo</a>
                            <?php else: ?>
                            * <a href="order-status.php?id=<?php echo $order['id'] ?>&status=1">
                            Mark as Delivered</a>
                        <?php endif; ?>
                    </td>

                    <td>
                        <?php
                        $order_id = $order['id'];
                        $items = mysqli_query($conn, "SELECT order_items.*, products.title
                        FROM order_items LEFT JOIN products ON order_items.product_id = products.id
                        WHERE order_items.order_id = $order_id
                        ");
                        while($item = mysqli_fetch_assoc($items)):
                        ?>
                            <a href="../product-detail.php?id=<?php echo $item['product_id'] ?>">
                                <?php echo $item['title'] ?>
                            </a>
                            (<?php echo $item['qty'] ?>)
                            </b>
                        <?php endwhile; ?>

                    </td>

                    <td>
                        <a href="order-delete.php?id=<?php echo $order['id'] ?>">
                            <button class="del_btn btn danger"> <i class="fas fa-trash-alt"></i> Delete</button>
                        </a>
                    </td>

                </tr>
            <?php endwhile; ?>
        </table>
        </div>



</div>
  </div>


<?php include 'layouts/footer.php';?>
