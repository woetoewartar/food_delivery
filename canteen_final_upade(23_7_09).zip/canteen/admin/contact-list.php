<?php
include("confs/auth.php");
include 'layouts/header.php';?>

<div id="content-wrapper">
    <div class="container-fluid">

    <!-- Here Start the list of canteens -->
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-bordered text-center" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Message</th>
              <th>Delete</th>
            </tr>
          </thead>
          <?php
            include("confs/config.php");
            $result = mysqli_query($conn, "SELECT * FROM contact_us");
          ?>
          <?php while($row = mysqli_fetch_assoc($result)): ?>
          <tr>
            <td><?php echo $row['name'] ?></td>
            <td><?php echo $row['email'] ?></td>
            <td><?php echo $row['message']; ?></td>
            <td><a href="contact-us-delete.php?id=<?php echo $row['id'] ?>"><button class="del_btn btn danger"> <i class="fas fa-trash-alt"></i> Delete</button></a></td>
          </tr>
          <?php endwhile; ?>
          <tbody>

          </tbody>
        </table>
      </div>
    </div>
    <!-- Here End the list of canteens -->
    </div>
  </div>

<?php include 'layouts/footer.php';?>
