<?php
    include("confs/config.php");
    $name = $_POST['title'];
    $body = $_POST['body'];
    $price = $_POST['price'];
    $canteen_id = $_POST['canteen_id'];
    $image = $_FILES['image']['name'];
    $filename = pathinfo($image, PATHINFO_FILENAME);
    $fileExt = pathinfo($image, PATHINFO_EXTENSION);
    $file = $filename.'_'.time().'.'.$fileExt;


    $tmp = $_FILES['image']['tmp_name'];
    if($file) {
    move_uploaded_file($tmp, "images/$file");
    }
    $sql = "INSERT INTO products (
    title, body, price, canteen_id,
    image, create_at, update_at
    ) VALUES (
    '$name', '$body', '$price',
    '$canteen_id', '$file', now(), now()
    )";
    mysqli_query($conn, $sql);
    header("location: product-list.php");
?>
