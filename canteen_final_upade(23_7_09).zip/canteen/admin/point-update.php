<?php
    include("confs/auth.php");
    include("confs/config.php");
    $id = $_POST['id'];
    $points = $_POST['points'];
    $sql = "UPDATE points SET points='$points', update_at=now() WHERE id = '$id' ";
    mysqli_query($conn, $sql);
    header("location: points.php");
?>
