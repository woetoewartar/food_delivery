<?php
include("confs/auth.php");
include 'layouts/header.php';?>

  <div id="content-wrapper">
    <div class="container-fluid">

      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="#">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Canteen</li>
      </ol>

      <div class=" col-sm-8 text-left">

      <form action="can-add.php"class="fun_add" method="post">
        <label for="name">Canteen Name</label>
        <input type="text" name="name" id="name">
        <label for="remark">Remark</label>
        <textarea name="remark" id="remark"style="width: 220px;border: 1px solid #90c322;border-radius: 5px;">
        </textarea>
        <br><br>
        <input type="submit" value="Add Canteen">
      </form>
      </div>


    </div>
  </div>

<?php include 'layouts/footer.php';?>


