<?php
//include("admin/confs/auth.php");
    include 'header.php';
    if(isset($_SESSION['auth_user'])){
        //echo ($_SESSION['auth_user']);
    }
?>
<section id="success">
	<div class="fluid-container">
			<div class="bg_image" style="background-image: url('images/hero_italian_blue.jpg');">
				
				<h2 class="about_title"> About Us</h2>
			</div>
			<div class="intro-section">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-12">
                <p>
                   Canteen Food Ordering Systems is an online ordering and food delivery service located in University. We make ordering food simple, fun, and accessible website or mobile devices. Our focus goes beyond food, partnering with university canteens and restaurants, bringing our customers the best experience possible. With Canteen Food Ordering Systems, you can save time, avoid stressful traffic and inclement weather, all while ordering from the comfort of your classroom or office. Now, "What will it be?" </p>
            </div>
            <!-- /.row -->
        </div>
        <!-- /.row -->

    <!-- /.row -->
</div>
	</div>
	    </div>
    <div class="fluid-container instructions">	
    	<div class="col-sm-4">
    		<img class="instructions__step-image" src="images/instructions-location.png">
    		<h4>Tell Us Where You Are</h4>
    		<p>In the box above, enter your name,phone number and optional address</p>
    	</div>
    	<div class="col-sm-4">
    		<img class="instructions__step-image" src="images/instructions-food.png">
    		<h4>Fill Your Basket</h4>
    		<p>Pick a restaurant from the list on the left and tell us what you'd like to order.</p>
    	</div>
    	<div class="col-sm-4">
    		<img class="instructions__step-image" src="images/instructions-doorbell.png">
    		<h4>Sit Back Relax</h4>
    		<p>Check out, and you'll have your food within 30 to 60 minutes.</p>
    	</div>

    </div>
    <div class="reviews">
<div class="review-container">
<p class="review-quote">Sit back and relax as the canteen prepares your order.</p>

</div>
</div>
</section>


<?php include 'footer.php';?>
