<!DOCTYPE HTML>
<html lang="en-US">
<head>
  <meta charset="UTF-8">
  <title>Admin Login</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../css/login.css">

  <link rel="stylesheet" href="../css/bootstrap.css">
  <link rel="stylesheet" href="../css/bootstrap.min.css">
  <link rel="icon" href="favicon.png" type="image/x-icon"/>

</head>
<body>
  <div class="login_body">
    <div class="container-fluid">
      <div class="col-sm-4"></div>
      <div class="col-sm-4">
        <div class="title_bar">
          Login to Control Panel
        </div>
        <form action="login_process.php" method="post" class="input_section">
          <div class="form-group">
            <input type="text" class="form-control login-field" placeholder="User Name" id="name" name="name">
          </div>
          <div class="form-group">
            <input type="password" class="form-control login-field last-field" placeholder="Your Password" id="password" name="password">
          </div>
          <input type="submit" class="submit-button correct" value="Admin Login"></input>
        </form>
      </div>
      <div class="col-sm-4"></div>
    </div>
  </div>
</body>
</html>
