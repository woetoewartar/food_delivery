<?php
  include("confs/config.php");

  $id = $_GET['id'];
  $sql = "DELETE FROM contact WHERE id = $id";
  mysqli_query($conn, $sql);

  header("location: contact-list.php");
?>
